#!/bin/bash

sudo apt-get update
sudo apt-get install -y docker.io git nginx

sudo systemctl start docker
sudo systemctl enable docker

git clone https://github.com/nytimes/covid-19-data /home/adminuser/covid-api

cd /home/adminuser/covid-api


echo 'FROM node:14
WORKDIR /usr/src/app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["node", "index.js"]' > Dockerfile

sudo docker build -t covid-api .
sudo docker run -d -p 3000:3000 covid-api

sudo rm /etc/nginx/sites-enabled/default
echo 'server {
    listen 80;
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}' | sudo tee /etc/nginx/sites-available/covid-api

# Enable the new site and restart Nginx
sudo ln -s /etc/nginx/sites-available/covid-api /etc/nginx/sites-enabled/
sudo systemctl restart nginx
